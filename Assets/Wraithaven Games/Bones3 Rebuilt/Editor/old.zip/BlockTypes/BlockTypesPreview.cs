using System.Collections.Generic;

using UnityEditor;

using UnityEngine;

namespace Bones3
{
    /// <summary>
    /// A utility class for rendering a block preview.
    /// </summary>
    public class BlockTypesPreview : System.IDisposable
    {
        private readonly PreviewRenderUtility previewUtility = new PreviewRenderUtility();
        private readonly LayeredProcMesh layeredProcMesh = new LayeredProcMesh();
        private readonly Mesh mesh = new Mesh();
        private readonly BlockTypes blockTypes;

        private readonly SingleBlockHolder singleBlockHolder = new SingleBlockHolder();
        private readonly ChunkProperties chunkProperties = new ChunkProperties(1);
        private readonly ChunkMesher chunkMesher;

        private Vector2 previewDir = new Vector2(45f, -30f);
        private Material[] materials = new Material[0];
        private int materialIndexPass;

        /// <summary>
        /// Creates a new block type preview object.
        /// </summary>
        /// <param name="blockTypes">The block type list to reference when rendering.</param>
        public BlockTypesPreview(BlockTypes blockTypes)
        {
            this.blockTypes = blockTypes;

            EditorUtility.SetCameraAnimateMaterials(previewUtility.camera, true);
            chunkMesher = new ChunkMesher(false, false, (chunk, b, j) =>
                chunk.GetBlock(b.x, b.y, b.z).Faces[j].TextureAtlas == materialIndexPass);
        }

        /// <summary>
        /// Cleans up this preview object.
        /// </summary>
        public void Dispose()
        {
            previewUtility.Cleanup();
            Object.DestroyImmediate(mesh);
        }

        /// <summary>
        /// Renders the preview.
        /// </summary>
        /// <param name="r">The display rect.</param>
        /// <param name="background">The background rendering style.</param>
        public void Render(Rect r, GUIStyle background)
        {
            if (!ShaderUtil.hardwareSupportsRectRenderTexture)
            {
                if (Event.current.type == EventType.Repaint)
                    EditorGUI.DropShadowLabel(new Rect(r.x, r.y, r.width, 40), "Unable to render\nblock preview");
                return;
            }

            UpdatePreviewDirection(r);

            if (Event.current.type != EventType.Repaint)
                return;

            previewUtility.BeginPreview(r, background);

            DoRenderPreview();

            previewUtility.EndAndDrawPreview(r);
        }

        /// <summary>
        /// Rotates the preview direction based on mouse inputs.
        /// </summary>
        /// <param name="position">The display rect.</param>
        /// <returns></returns>
        void UpdatePreviewDirection(Rect position)
        {
            int sliderHash = "Slider".GetHashCode();
            int id = GUIUtility.GetControlID(sliderHash, FocusType.Passive);
            Event evt = Event.current;

            switch (evt.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (position.Contains(evt.mousePosition) && position.width > 50)
                    {
                        GUIUtility.hotControl = id;
                        evt.Use();
                        EditorGUIUtility.SetWantsMouseJumping(1);
                    }
                    break;

                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id)
                    {
                        previewDir -= evt.delta * (evt.shift ? 3 : 1) / Mathf.Min(position.width, position.height) * 140.0f;
                        evt.Use();
                        GUI.changed = true;
                    }
                    break;

                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id)
                        GUIUtility.hotControl = 0;

                    EditorGUIUtility.SetWantsMouseJumping(0);
                    break;
            }
        }

        void DoRenderPreview()
        {
            previewUtility.camera.transform.position = -Vector3.forward * 7f;
            previewUtility.camera.transform.rotation = Quaternion.identity;

            previewUtility.lights[0].intensity = 1.0f;
            previewUtility.lights[0].transform.rotation = Quaternion.Euler(50f, 50f, 0f);
            previewUtility.lights[1].intensity = 1.0f;

            previewUtility.ambientColor = new Color(0.2f, 0.2f, 0.2f, 0f);

            Quaternion rot = Quaternion.Euler(previewDir.y, 0, 0) * Quaternion.Euler(0, previewDir.x, 0);

            previewUtility.camera.transform.position = Quaternion.Inverse(rot) * previewUtility.camera.transform.position;
            previewUtility.camera.transform.LookAt(Vector3.zero);

            for (int i = 0; i < materials.Length; i++)
                previewUtility.DrawMesh(mesh, Vector3.one * -0.5f, Quaternion.identity, materials[i], i);

            previewUtility.Render(true);
        }

        public void RebuildMesh(BlockType blockType)
        {
            mesh.Clear();

            if (!blockType.IsVisible)
                return;

            List<int> atlases = new List<int>();
            for (int j = 0; j < 6; j++)
            {
                int atlas = blockType.Faces[j].TextureAtlas;
                if (!atlases.Contains(atlas))
                    atlases.Add(atlas);
            }

            while (layeredProcMesh.TotalLayers < atlases.Count)
                layeredProcMesh.AddLayer(new ProcMesh());

            singleBlockHolder.SetBlock(0, 0, 0, blockType.ID);
            chunkProperties.Set(singleBlockHolder, blockTypes, new IBlockHolder[6]);

            for (int a = 0; a < atlases.Count; a++)
            {
                materialIndexPass = atlases[a];
                chunkMesher.Remesh(chunkProperties, layeredProcMesh.GetMesh(a));
            }

            materials = new Material[atlases.Count];
            for (int i = 0; i < materials.Length; i++)
                if (atlases[i] < blockTypes.TextureAtlasCount)
                    materials[i] = blockTypes.GetAtlas(atlases[i]);

            layeredProcMesh.Apply(mesh);
            layeredProcMesh.Clear();
        }

        class SingleBlockHolder : IBlockHolder
        {
            ushort block;

            public int ChunkSize => 1;
            public int BlockCount => 1;
            public void GetBlocks(ushort[] buffer) => buffer[0] = block;
            public ushort GetBlock(int x, int y, int z) => block;
            public void SetBlock(int x, int y, int z, ushort blockId) => this.block = blockId;
        }
    }
}
