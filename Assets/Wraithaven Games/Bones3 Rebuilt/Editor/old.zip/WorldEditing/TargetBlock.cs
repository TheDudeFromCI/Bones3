using UnityEngine;

namespace Bones3
{
    /// <summary>
    /// The block being targeting while world editing.
    /// </summary>
    public struct TargetBlock
    {
        private Vector3Int blockInside;
        private Vector3Int blockOver;
        private int side;
        private bool hasBlock;
        private bool hasShift;

        /// <summary>
        /// The block coordinates the cursor is in.
        /// </summary>
        public Vector3Int Inside { get => blockInside; set => blockInside = value; }

        /// <summary>
        /// The block coordinates the cursor is over.
        /// </summary>
        public Vector3Int Over { get => blockOver; set => blockOver = value; }

        /// <summary>
        /// The side of the block being targeted.
        /// </summary>
        public int Side
        {
            get => side;
            set
            {
                if (value < 0 || value > 5)
                    throw new System.ArgumentException($"Unknown direction {value}!");

                side = value;
            }
        }

        /// <summary>
        /// Whether or not a block is being targeted, or if the mouse is over empty space.
        /// </summary>
        public bool HasBlock { get => hasBlock; set => hasBlock = value; }

        /// <summary>
        /// Whether or not the shift button is being held.
        /// </summary>
        public bool HasShift { get => hasShift; set => hasShift = value; }
    }
}
