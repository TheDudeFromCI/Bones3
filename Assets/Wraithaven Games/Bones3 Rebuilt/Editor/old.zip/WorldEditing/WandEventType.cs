namespace Bones3
{
    public enum WandEventType
    {
        MouseDown,
        MouseUp,
        MouseMove,
        ExitWindow,
    }
}
